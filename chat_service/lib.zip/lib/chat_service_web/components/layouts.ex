defmodule ChatServiceWeb.Layouts do
  use ChatServiceWeb, :html

  embed_templates "layouts/*"
end
