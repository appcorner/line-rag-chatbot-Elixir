defmodule ChatService.Agents.Tools.TopGames do
  @moduledoc false

  @behaviour ChatService.Agents.Tool

  require Logger

  @api_url "https://api.w1a.dev/api/games/top10"

  @impl true
  def name, do: "get_top_games"

  @impl true
  def definition do
    %{
      name: name(),
      description: "ดึงข้อมูลเกมยอดนิยม Top 10 จาก API",
      parameters: %{
        type: "object",
        properties: %{},
        required: []
      }
    }
  end

  @impl true
  def enabled?, do: true

  @impl true
  def execute(_params) do
    Logger.info("[TopGames] Fetching top games from API")

    request = Finch.build(:get, @api_url, [{"accept", "application/json"}])

    case Finch.request(request, ChatService.Finch, receive_timeout: 30_000) do
      {:ok, %Finch.Response{status: 200, body: body}} ->
        {:ok, body}

      {:ok, %Finch.Response{status: status, body: body}} ->
        Logger.error("[TopGames] API error: #{status} - #{body}")
        {:error, "API error: #{status}"}

      {:error, reason} ->
        Logger.error("[TopGames] Request failed: #{inspect(reason)}")
        {:error, "Failed to fetch top games: #{inspect(reason)}"}
    end
  end
end
